using Microsoft.EntityFrameworkCore;
using ApiCrudApp.Models;

var builder = WebApplication.CreateBuilder(args);

// Configurar Entity Framework con MySQL
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(builder.Configuration.GetConnectionString("DefaultConnection"), 
    ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("DefaultConnection"))));

// Agregar servicios para controladores
builder.Services.AddControllers();

var app = builder.Build();

// Configuración de middlewares
app.UseAuthorization();

app.MapControllers();

app.Run();

